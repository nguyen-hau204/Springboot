package com.example.demo1s.Controller;
import com.example.demo1s.model.nhanvien;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;

@Controller
public class MyController {
    ArrayList<nhanvien> listnv = new ArrayList<>();

    public MyController(ArrayList<nhanvien> listnv) {
        this.listnv = listnv;
        listnv.add(new nhanvien(1,"nv01","nguyễn hữu hậu","0999876544"));
        listnv.add(new nhanvien(2,"nv02","nguyễn hậu 2","0999876544"));
    }

    @GetMapping("/s")
    public String home(Model model) {
        model.addAttribute("listnv",listnv);
        model.addAttribute("s1","đây là trang chủ");
        model.addAttribute("s2","nguyen hau");
        return "index"; // Trả về tên của tệp HTML (không cần phần mở rộng .html)
    }

    @PostMapping("/add")
    public String add(@RequestParam("id") int id , @RequestParam("ma") String ma , @RequestParam("ten") String ten , @RequestParam("sdt") String sdt){
        nhanvien nhanvien = new nhanvien();
        nhanvien.setId(id);
        nhanvien.setMa(ma);
        nhanvien.setSdt(sdt);
        nhanvien.setTen(ten);
        listnv.add(nhanvien);
        return "redirect:/s";
    }

    @GetMapping("/onclick")
    public ModelAndView  onclick(Model model , @RequestParam("id") int id){
        nhanvien nhanvien = new nhanvien();

        for (nhanvien nv: listnv) {
            if (nv.getId() == id){
                nhanvien = nv;
            }
        }
        System.out.printf(nhanvien.toString());
        model.addAttribute("listnv",listnv);
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("nhanvien",nhanvien);
        return modelAndView;

    }

    @GetMapping("/xoa")
    public String xoa(@RequestParam("id") int id){
        nhanvien nhanvien = new nhanvien();

        for (nhanvien nv: listnv) {
            if (nv.getId() == id){
                nhanvien = nv;
            }
        }
        listnv.remove(nhanvien);
        return "redirect:/s";
    }

}
