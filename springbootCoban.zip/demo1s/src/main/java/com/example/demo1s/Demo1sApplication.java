package com.example.demo1s;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1sApplication {

    public static void main(String[] args) {
        SpringApplication.run(Demo1sApplication.class, args);
    }

}
