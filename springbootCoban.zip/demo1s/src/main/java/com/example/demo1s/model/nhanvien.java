package com.example.demo1s.model;

public class nhanvien {
    private int id;
    private String ma;
    private String ten;
    private String sdt;

    public nhanvien() {
    }

    public nhanvien(int id, String ma, String ten, String sdt) {
        this.id = id;
        this.ma = ma;
        this.ten = ten;
        this.sdt = sdt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    @Override
    public String toString() {
        return "nhanvien{" +
                "id=" + id +
                ", ma='" + ma + '\'' +
                ", ten='" + ten + '\'' +
                ", sdt='" + sdt + '\'' +
                '}';
    }
}
